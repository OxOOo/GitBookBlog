#include <QApplication>
#include <QLabel>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    // 开始设置窗口
    QLabel w;
    w.setText("Hello Animation");
    w.resize(400, 300);
    w.setAlignment(Qt::AlignCenter);
    w.show();
    // 设置窗口结束

    // 开始设置动画1
    QPropertyAnimation *animation1 = new QPropertyAnimation(&w, "pos"); // 设置动画的对象和属性
    animation1->setStartValue(QPoint(200, 200)); // 设置动画开始时的属性值
    animation1->setEndValue(QPoint(800, 500)); // 设置动画结束时的属性值
    animation1->setDuration(2000); // 设置动画的持续时间
    // 设置动画结束1

    // 开始设置动画2
    QPropertyAnimation *animation2 = new QPropertyAnimation(&w, "size"); // 设置动画的对象和属性
    animation2->setStartValue(QSize(400, 300)); // 设置动画开始时的属性值
    animation2->setEndValue(QSize(160, 120)); // 设置动画结束时的属性值
    animation2->setDuration(2000); // 设置动画的持续时间
    // 设置动画结束2

    // 将两个动画添加到串行动画组中
    QSequentialAnimationGroup group; // 可以将QSequentialAnimationGroup替换成QParallelAnimationGroup试试
    group.addAnimation(animation1);
    group.addAnimation(animation2);

    // 开始动画
    group.start(); // !!! 注意此处

    return app.exec();
}
