#include <QApplication>
#include <QLabel>
#include <QPropertyAnimation>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    // 开始设置窗口
    QLabel w;
    w.setText("Hello Animation");
    w.resize(400, 300);
    w.setAlignment(Qt::AlignCenter);
    w.show();
    // 设置窗口结束

    // 开始设置动画
    QPropertyAnimation animation(&w, "pos"); // 设置动画的对象和属性
    animation.setStartValue(QPoint(200, 200)); // 设置动画开始时的属性值
    animation.setEndValue(QPoint(800, 500)); // 设置动画结束时的属性值
    animation.setDuration(2000); // 设置动画的持续时间
    animation.setEasingCurve(QEasingCurve::OutBounce); // !!! 修改了这里，使用缓和曲线
    // 设置动画结束

    // 开始动画
    animation.start();

    return app.exec();
}
